/* 
 * Copyright (c) 2002-2005 LWJGL Project
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are 
 * met:
 * 
 * * Redistributions of source code must retain the above copyright 
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'LWJGL' nor the names of 
 *   its contributors may be used to endorse or promote products derived 
 *   from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.lwjgl.devil;

import java.io.File;
import java.security.AccessController;
import java.security.PrivilegedAction;

import org.lwjgl.LWJGLException;
import org.lwjgl.LWJGLUtil;

/**
 * <p>
 * Native interface for DevIL
 * </p>
 * 
 * @author Brian Matzon <brian@matzon.dk>
 * @version $Revision: 2935 $
 * $Id: ILNative.java 2935 2008-01-20 08:20:54Z matzon $
 */
class ILNative {
	
	/** The native JNI library name */
	private static String JNI_LIBRARY_NAME = "lwjgl-devil";

	/** Version of IL */
	static final String VERSION = "1.1.4";
	
	/** Current version of the JNI library */
	static final int JNI_VERSION = 2;	

	private static void loadLibrary(final String lib_name) {
		AccessController.doPrivileged(new PrivilegedAction() {
			public Object run() {
				String library_path = System.getProperty("org.lwjgl.librarypath");
				if (library_path != null) {
					System.load(library_path + File.separator + 
						System.mapLibraryName(lib_name));
				} else {
					System.loadLibrary(lib_name);
				}
				return null;
			}
		});
	}	

	static {
		loadLibrary(JNI_LIBRARY_NAME);
		
		// check for mismatch
		int nativeVersion = getNativeLibraryVersion();
		if (nativeVersion != JNI_VERSION) {
			throw new LinkageError(
					"Version mismatch: jar version is '" + JNI_VERSION + 
					"', native libary version is '" + nativeVersion + "'");
		}		
	}
	
	// IL
	// ===========================================================
	static native void initNativeStubsIL(Class clazz) throws LWJGLException;
	static native void resetNativeStubsIL(Class clazz);
	static native void nCreateIL(String[] ilPaths) throws LWJGLException;
	static native void nDestroyIL();
	private static native int getNativeLibraryVersion();  	

	static void createIL() throws LWJGLException {
		String libname;
		String platform_libname;
		switch (LWJGLUtil.getPlatform()) {
			case LWJGLUtil.PLATFORM_WINDOWS:
				libname = "DevIL";
				platform_libname = "DevIL.dll";
				break;
			case LWJGLUtil.PLATFORM_LINUX:
				libname = "IL";
				platform_libname = "libIL.so";
				break;
			case LWJGLUtil.PLATFORM_MACOSX:
				libname = "IL";
				platform_libname = "libIL.dylib";
				break;
			default:
				throw new LWJGLException("Unknown platform: " + LWJGLUtil.getPlatform());
		}
		String[] illPaths = LWJGLUtil.getLibraryPaths(libname, platform_libname, IL.class.getClassLoader());
		ILNative.nCreateIL(illPaths);
		
		try {
			ILNative.initNativeStubsIL(IL.class);
			IL.ilInit();
		} catch (LWJGLException e) {
			IL.destroy();
			throw e;
		}		
	}
	
	public static void destroyIL() {
		ILNative.resetNativeStubsIL(IL.class);
		ILNative.nDestroyIL();
	}
	// -----------------------------------------------------------
	
	
	// ILU
	// ===========================================================
	static native void initNativeStubsILU(Class clazz) throws LWJGLException;
	static native void resetNativeStubsILU(Class clazz);
	static native void nCreateILU(String[] iluPaths) throws LWJGLException;
	static native void nDestroyILU();
	
	static void createILU() throws LWJGLException {
		String libname;
		switch (LWJGLUtil.getPlatform()) {
			case LWJGLUtil.PLATFORM_WINDOWS:
				libname = "ILU.dll";
				break;
			case LWJGLUtil.PLATFORM_LINUX:
				libname = "libILU.so";
				break;
			case LWJGLUtil.PLATFORM_MACOSX:
				libname = "libILU.dylib";
				break;
			default:
				throw new LWJGLException("Unknown platform: " + LWJGLUtil.getPlatform());
		}

		String[] iluPaths = LWJGLUtil.getLibraryPaths("ILU", libname, ILU.class.getClassLoader());
		ILNative.nCreateILU(iluPaths);
		
		try {
			ILNative.initNativeStubsILU(ILU.class);
			ILU.iluInit();
		} catch (LWJGLException e) {
			ILU.destroy();
			throw e;
		}		
	}
	
	public static void destroyILU() {
		ILNative.resetNativeStubsILU(ILU.class);
		ILNative.nDestroyILU();
	}	
	// -----------------------------------------------------------	

	// ILU
	// ===========================================================
	static native void initNativeStubsILUT(Class clazz) throws LWJGLException;
	static native void resetNativeStubsILUT(Class clazz);
	static native void nCreateILUT(String[] ilutPaths) throws LWJGLException;
	static native void nDestroyILUT();
	
	static void createILUT() throws LWJGLException {
		String libname;
		switch (LWJGLUtil.getPlatform()) {
			case LWJGLUtil.PLATFORM_WINDOWS:
				libname = "ILUT.dll";
				break;
			case LWJGLUtil.PLATFORM_LINUX:
				libname = "libILUT.so";
				break;
			case LWJGLUtil.PLATFORM_MACOSX:
				libname = "libILUT.dylib";
				break;
			default:
				throw new LWJGLException("Unknown platform: " + LWJGLUtil.getPlatform());
		}
		String[] ilutPaths = LWJGLUtil.getLibraryPaths("ILUT", libname, ILUT.class.getClassLoader());
		ILNative.nCreateILUT(ilutPaths);
		
		try {
			ILNative.initNativeStubsILUT(ILUT.class);
			ILUT.ilutInit();
		} catch (LWJGLException e) {
			ILUT.destroy();
			throw e;
		}		
	}
	
	public static void destroyILUT() {
		ILNative.resetNativeStubsILUT(ILUT.class);
		ILNative.nDestroyILUT();
	}	
	// -----------------------------------------------------------	
}
