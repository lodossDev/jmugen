/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class NVPackedDepthStencil {
	public static final int GL_DEPTH_STENCIL_NV = 0x84f9;
	public static final int GL_UNSIGNED_INT_24_8_NV = 0x84fa;

	private NVPackedDepthStencil() {
	}

}
