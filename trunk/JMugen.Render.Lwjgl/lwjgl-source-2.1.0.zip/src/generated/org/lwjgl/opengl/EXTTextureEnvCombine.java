/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class EXTTextureEnvCombine {
	public static final int GL_COMBINE_EXT = 0x8570;
	public static final int GL_COMBINE_RGB_EXT = 0x8571;
	public static final int GL_COMBINE_ALPHA_EXT = 0x8572;
	public static final int GL_SOURCE0_RGB_EXT = 0x8580;
	public static final int GL_SOURCE1_RGB_EXT = 0x8581;
	public static final int GL_SOURCE2_RGB_EXT = 0x8582;
	public static final int GL_SOURCE0_ALPHA_EXT = 0x8588;
	public static final int GL_SOURCE1_ALPHA_EXT = 0x8589;
	public static final int GL_SOURCE2_ALPHA_EXT = 0x858a;
	public static final int GL_OPERAND0_RGB_EXT = 0x8590;
	public static final int GL_OPERAND1_RGB_EXT = 0x8591;
	public static final int GL_OPERAND2_RGB_EXT = 0x8592;
	public static final int GL_OPERAND0_ALPHA_EXT = 0x8598;
	public static final int GL_OPERAND1_ALPHA_EXT = 0x8599;
	public static final int GL_OPERAND2_ALPHA_EXT = 0x859a;
	public static final int GL_RGB_SCALE_EXT = 0x8573;
	public static final int GL_ADD_SIGNED_EXT = 0x8574;
	public static final int GL_INTERPOLATE_EXT = 0x8575;
	public static final int GL_CONSTANT_EXT = 0x8576;
	public static final int GL_PRIMARY_COLOR_EXT = 0x8577;
	public static final int GL_PREVIOUS_EXT = 0x8578;

	private EXTTextureEnvCombine() {
	}

}
