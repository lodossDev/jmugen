/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class EXTRescaleNormal {
	public static final int GL_RESCALE_NORMAL_EXT = 0x803a;

	private EXTRescaleNormal() {
	}

}
