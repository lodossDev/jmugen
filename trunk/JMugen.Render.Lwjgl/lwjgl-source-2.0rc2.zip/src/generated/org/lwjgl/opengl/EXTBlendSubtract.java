/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class EXTBlendSubtract {
	public static final int GL_FUNC_SUBTRACT_EXT = 0x800a;
	public static final int GL_FUNC_REVERSE_SUBTRACT_EXT = 0x800b;

	private EXTBlendSubtract() {
	}

}
