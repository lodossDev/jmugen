/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class NVDepthClamp {
	public static final int GL_DEPTH_CLAMP_NV = 0x864f;

	private NVDepthClamp() {
	}

}
